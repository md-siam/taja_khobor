//home_screen & news_screen
export 'circular_clipper.dart';
export 'content_scroll.dart';

//custom drawer
export 'custom_drawer.dart';
//export 'custom_drawer1.dart'; //activate this for android device only

//news categories in home.dart
export 'news_categories.dart';

//navigation drawer
export 'custom_ListTile.dart';

//bookmarks
export 'bookmarks_categorymenu.dart';

//sports
export 'sports_categorymenu.dart';

//stocks
export 'stocksList.dart';
export 'stocksNewsList.dart';

//jobs
export 'jobs_categorymenu.dart';
export 'jobs_container.dart';

//audio books
export 'audiobooks_categorymenu.dart';
export 'audiobooks_container.dart';
export 'audiobooks_rating.dart';
