import 'package:flutter/material.dart';

class WalletScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar:AppBar(
        iconTheme: IconThemeData(color: Theme.of(context).cardColor),
        title: Text('Wallet'),
      ),
      body: Column(
        children: <Widget>[
          Container(
            padding: EdgeInsets.only(top:250),
            child: Text("No wallet information available.", style:TextStyle(fontSize: 16)),
          ),
        ],
      ),
    );
  }
}
