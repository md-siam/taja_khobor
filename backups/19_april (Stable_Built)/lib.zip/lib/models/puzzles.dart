List<String> puzzlesCategories = [
  'Solitaire',
  'Ludo',
  'Sudoku',
  'Tetris',
  'Jigsaw',
  'Rubik\'s Cube',
];