import 'package:flutter/material.dart';
import '../models/models.dart';
import '../widgets/widgets.dart';
import '../screens/screens.dart';

class WalletScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Wallet"),
        iconTheme: IconThemeData(color: Theme.of(context).cardColor),
        elevation: 0,
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(15.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            SizedBox(
              height: 15.0,
            ),
            Container(
              padding: EdgeInsets.all(25.0),
              decoration: BoxDecoration(
                color: darkBlue,
                borderRadius: BorderRadius.circular(15.0),
              ),
              child: Column(
                //crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(
                    "Available Credits",
                    style: TextStyle(
                      fontSize: 19,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                  SizedBox(
                    height: 11.0,
                  ),
                  RichText(
                    text: TextSpan(
                      children: [
                        TextSpan(
                          text: "691.00",
                          style: Theme.of(context)
                              .textTheme
                              .display1
                              .apply(color: Colors.white, fontWeightDelta: 2),
                        ),
                        TextSpan(text: " ₵REDITS")
                      ],
                    ),
                  ),
                  SizedBox(
                    height: 11.0,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: <Widget>[
                      SizedBox(width: 15.0),
                      Flexible(
                        child: RaisedButton(
                          padding: EdgeInsets.symmetric(
                              horizontal: 15.0, vertical: 11.0),
                          color: lightBlue,
                          onPressed: () {
                            print('Withdraw pressed');
                          },
                          child: Text(
                            'Withdraw',
                            style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold),
                          ),
                          shape: RoundedRectangleBorder(
                            borderRadius: new BorderRadius.circular(9.0),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            Container(
              margin: EdgeInsets.symmetric(vertical: 15.0),
              height: MediaQuery.of(context).size.height / 4,
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                itemCount: historyContainerList.length,
                itemBuilder: (ctx, i) {
                  return WalletHistoryContainer(id: i);
                },
              ),
            ),
            Row(
              children: <Widget>[
                Expanded(
                  child: Text(
                    "Transaction History",
                    style: TextStyle(
                      color: Theme.of(context).cardColor,
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                Icon(
                  Icons.timelapse,
                  color: Theme.of(context).cardColor,
                ),
                Text(
                  "Last 24 hours",
                  style: TextStyle(
                    color: Theme.of(context).cardColor,
                  ),
                ),
              ],
            ),
            Divider(
              height: 31,
              color: Theme.of(context).cardColor,
            ),
            Row(
              children: <Widget>[
                Flexible(
                  flex: 3,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(
                        "Referral Credits                        ",
                        style: Theme.of(context)
                            .textTheme
                            .title
                            .apply(fontWeightDelta: 2),
                      ),
                      Text(
                        "It takes around 24 hours",
                        style: Theme.of(context).textTheme.subhead,
                      ),
                    ],
                  ),
                ),
                Flexible(
                  child: Column(
                    children: <Widget>[
                      Text(
                        "70.00 ₵",
                        style: TextStyle(
                          color: Theme.of(context).cardColor,
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                        ),
                        textAlign: TextAlign.center,
                      ),
                      RaisedButton(
                        color: lightBlue,
                        child: Text(
                          "View",
                          style: TextStyle(color: Colors.white),
                        ),
                        shape: RoundedRectangleBorder(
                          borderRadius: new BorderRadius.circular(9.0),
                        ),
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => ReferralCreditsScreen(),
                            ),
                          );
                        },
                      ),
                    ],
                  ),
                ),
              ],
            ),
            Divider(height: 30),
            Row(
              children: <Widget>[
                Flexible(
                  flex: 3,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(
                        "Transfer Credits                        ",
                        style: Theme.of(context)
                            .textTheme
                            .title
                            .apply(fontWeightDelta: 2),
                      ),
                      Text(
                        "It takes around 2 hours",
                        style: Theme.of(context).textTheme.subhead,
                      ),
                    ],
                  ),
                ),
                Flexible(
                  child: Column(
                    children: <Widget>[
                      Text(
                        "1500.00 ₵",
                        style: TextStyle(
                          color: Theme.of(context).cardColor,
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                        ),
                        textAlign: TextAlign.center,
                      ),
                      RaisedButton(
                        color: lightBlue,
                        child: Text(
                          "View",
                          style: TextStyle(color: Colors.white),
                        ),
                        shape: RoundedRectangleBorder(
                          borderRadius: new BorderRadius.circular(9.0),
                        ),
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => TransferCreditsScreen(),
                            ),
                          );
                        },
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
