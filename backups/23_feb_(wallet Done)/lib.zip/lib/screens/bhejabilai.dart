import 'package:flutter/material.dart';

class BhejaBilaiScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        iconTheme: IconThemeData(color: Theme.of(context).cardColor),
        title: Text('Bheja Bilai'),
      ),
      body: Column(
        children: <Widget>[
          Container(
            padding: EdgeInsets.only(top: 250),
            child: Text("            No Bheja Bilai information available.",
                style: TextStyle(fontSize: 16)),
          ),
        ],
      ),
    );
  }
}
