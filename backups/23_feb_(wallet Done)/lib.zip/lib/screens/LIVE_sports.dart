import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import '../widgets/widgets.dart';

class LIVE_SportsScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    var titleTextStyle = TextStyle(
      fontSize: 20.0,
      fontWeight: FontWeight.bold,
    );
    var teamNameTextStyle = TextStyle(
      fontSize: 18.0,
      fontWeight: FontWeight.w500,
    );

    return Scaffold(
      appBar: AppBar(
        iconTheme: IconThemeData(color: Theme.of(context).cardColor),
        title: Text('LIVE Sports'),
      ),
      body: Column(
        children: <Widget>[
          Container(
            padding: EdgeInsets.all(15),
            color: Theme.of(context).secondaryHeaderColor,
            child: Column(
              children: <Widget>[
                SizedBox(
                  height: 25,
                  child: SportsCategoryMenu(),
                )
              ],
            ),
          ),
          Expanded(
            child: ListView(
              padding: const EdgeInsets.all(16.0),
              children: <Widget>[
                const SizedBox(height: 16.0),
                Card(
                  color: Theme.of(context).accentColor,
                  elevation: 4.0,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10.0),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Row(
                      children: <Widget>[
                        CircleAvatar(
                          backgroundImage: ExactAssetImage(
                              "assets/images/LIVE_Sports/flags/bangladesh.png"),
                        ),
                        Spacer(),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: <Widget>[
                            Text(
                              "Bangladesh",
                              style: teamNameTextStyle,
                            ),
                            const SizedBox(height: 5.0),
                            Text(
                              "329/6",
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 18.0,
                              ),
                            ),
                          ],
                        ),
                        Padding(
                          padding: const EdgeInsets.only(
                              top: 20.0, left: 20.0, right: 20.0),
                          child: Text(
                            ":",
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 18.0,
                            ),
                          ),
                        ),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Text(
                              "Pakistan",
                              style: teamNameTextStyle,
                            ),
                            const SizedBox(height: 5.0),
                            Text(
                              "250/10",
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 18.0,
                              ),
                            ),
                          ],
                        ),
                        Spacer(),
                        CircleAvatar(
                          backgroundImage: ExactAssetImage(
                              "assets/images/LIVE_Sports/flags/pakistan.png"),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 16.0),
                Card(
                  color: Theme.of(context).accentColor,
                  elevation: 4.0,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10.0),
                  ),
                  child: Stack(
                    children: <Widget>[
                      Column(
                        children: <Widget>[
                          Container(
                            height: 200.0,
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.only(
                                  topLeft: Radius.circular(10.0),
                                  topRight: Radius.circular(10.0),
                                ),
                                image: DecorationImage(
                                  image: ExactAssetImage(
                                      "assets/images/LIVE_Sports/Mushfiqur0.jpg"),
                                  fit: BoxFit.cover,
                                )),
                          ),
                          Padding(
                            padding: const EdgeInsets.all(16.0),
                            child: Text(
                              "Bangladesh 329 for 6, beat Pakistan by 79 runs",
                              style: titleTextStyle,
                            ),
                          ),
                          Padding(
                            padding:
                                const EdgeInsets.symmetric(horizontal: 16.0),
                            child: Row(
                              children: <Widget>[
                                Text(
                                  "Today, 9:24 PM",
                                  style: TextStyle(
                                    color: Colors.grey,
                                    fontSize: 14.0,
                                  ),
                                ),
                                Spacer(),
                                Text(
                                  "Dhaka | Bangladesh",
                                  style: TextStyle(
                                    color: Colors.grey,
                                    fontSize: 14.0,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(height: 20.0),
                        ],
                      ),
                      Positioned(
                        top: 190,
                        left: 20.0,
                        child: Container(
                          color: Colors.green,
                          padding: const EdgeInsets.all(4.0),
                          child: Text(
                            "LIVE",
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 12.0,
                            ),
                          ),
                        ),
                      )
                    ],
                  ),
                ),
                const SizedBox(height: 10.0),
                Divider(),
                const SizedBox(height: 10.0),
                ListTile(
                  title: Text(
                    "Mushfiqur Rahim's fourth ODI century",
                    style: titleTextStyle,
                  ),
                  subtitle: Text("Today, 7:02 PM | Dhaka"),
                  trailing: Container(
                    width: 80.0,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10.0),
                        image: DecorationImage(
                          image: ExactAssetImage(
                              "assets/images/LIVE_Sports/Mushfiqur1.jpg"),
                          fit: BoxFit.cover,
                        )),
                  ),
                ),
                const SizedBox(height: 10.0),
                ListTile(
                  title: Text(
                    "Tamim Iqbal's 132 against Pakistan",
                    style: titleTextStyle,
                  ),
                  subtitle: Text("Today, 7:02 PM | Dhaka"),
                  trailing: Container(
                    width: 80.0,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10.0),
                        image: DecorationImage(
                          image: ExactAssetImage(
                              "assets/images/LIVE_Sports/Tamim.jpg"),
                          fit: BoxFit.cover,
                        )),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        selectedItemColor: Colors.blue,
        currentIndex: 0,
        elevation: 0,
        items: [
          BottomNavigationBarItem(
            icon: Icon(FontAwesomeIcons.listAlt),
            title: Padding(
              padding: const EdgeInsets.only(top: 4.0),
              child: Icon(
                FontAwesomeIcons.solidCircle,
                size: 8.0,
                color: Colors.blue,
              ),
            ),
          ),
          BottomNavigationBarItem(
            icon: Icon(FontAwesomeIcons.bookmark),
            title: Text(""),
          ),
          BottomNavigationBarItem(
            icon: Icon(FontAwesomeIcons.chartBar),
            title: Text(""),
          ),
          BottomNavigationBarItem(
            icon: Icon(FontAwesomeIcons.clipboard),
            title: Text(""),
          ),
        ],
      ),
    );
  }
}
