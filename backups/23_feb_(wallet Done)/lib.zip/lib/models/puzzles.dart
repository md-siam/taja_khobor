List<String> puzzlesCategories = [
  'Sudoku',
  'Tetris',
  'Jigsaw',
  'Rubik\'s Cube',
];