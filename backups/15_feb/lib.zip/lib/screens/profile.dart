import 'package:flutter/material.dart';
import 'package:circular_profile_avatar/circular_profile_avatar.dart';
import '../widgets/widgets.dart';

class ProfileScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        iconTheme: IconThemeData(color: Theme.of(context).cardColor),
        title: Text('Profile'),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: <Widget>[
            //StackContainer(),
            Stack(
              children: <Widget>[
                Container(),
                ClipPath(
                  clipper: ProfileClipper(),
                  child: Container(
                    height: 300.0,
                    decoration: BoxDecoration(
                      color: Theme.of(context).secondaryHeaderColor,
                    ),
                  ),
                ),
                Container(
                  height: 200,
                  child: Align(
                    alignment: Alignment(0, 1),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: <Widget>[
                        CircularProfileAvatar(
                          "https://i.ibb.co/0QRNwzd/mdsiam.png",
                          borderWidth: 4.0,
                          radius: 60.0,
                        ),
                        SizedBox(height: 4.0),
                        Text(
                          "Md. Siam",
                          style: TextStyle(
                            fontSize: 22.0,
                            fontWeight: FontWeight.bold, color: Colors.white
                          ),
                        ),
                        Text(
                          "Student",
                          style: TextStyle(color: Colors.white,),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
