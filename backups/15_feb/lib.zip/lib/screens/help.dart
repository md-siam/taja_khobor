import 'package:flutter/material.dart';

class HelpScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Help'),
        iconTheme: IconThemeData(color: Theme.of(context).cardColor),
      ),
    );
  }
}
