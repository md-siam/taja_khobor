import 'package:flutter/material.dart';
import '../widgets/widgets.dart';

class BookmarksScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar:AppBar(
        iconTheme: IconThemeData(color: Theme.of(context).cardColor),
        title: Text('Bookmarks'),
      ),
      body: Column(
        children: <Widget>[
          Container(
            padding: EdgeInsets.all(15),
            color: Theme.of(context).secondaryHeaderColor,
            child: Column(
              children: <Widget>[
                SizedBox(
                  height: 25,
                  child: BookmarksCategoryMenu(),
                )
              ],
            ),
          ),
        ],
      ),
    );
  }
}
