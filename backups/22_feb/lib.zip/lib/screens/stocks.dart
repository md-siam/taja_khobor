import 'package:flutter/material.dart';

class StocksScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        iconTheme: IconThemeData(color: Theme.of(context).cardColor),
        title: Text('Stocks'),
      ),
      body: Column(
        children: <Widget>[
          Container(
            padding: EdgeInsets.only(top: 250),
            child: Text("No stocks information available.",
                style: TextStyle(fontSize: 16)),
          ),
        ],
      ),
    );
  }
}
