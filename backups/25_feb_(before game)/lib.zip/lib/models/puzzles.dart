List<String> puzzlesCategories = [
  'Solitaire',
  'Sudoku',
  'Tetris',
  'Jigsaw',
  'Rubik\'s Cube',
];