//home_screen & news_screen
export 'news_details.dart';
export 'jobs_details.dart';
export 'audiobooks_details.dart';

//side navigator
export 'splash_screen.dart';
export 'home.dart';
export 'bookmarks.dart';
export 'sports.dart';
export 'profile.dart';
export 'jobs.dart';
export 'audiobooks.dart';
export 'settings.dart';
export 'help.dart';
