import 'package:flutter/material.dart';
import '../widgets/widgets.dart';

class SportsScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        iconTheme: IconThemeData(color: Theme.of(context).cardColor),
        title: Text('Sports'),
      ),
      body: Column(
        children: <Widget>[
          Container(
            padding: EdgeInsets.all(15),
            color: Theme.of(context).secondaryHeaderColor,
            child: Column(
              children: <Widget>[
                SizedBox(
                  height: 25,
                  child: SportsCategoryMenu(),
                )
              ],
            ),
          ),
          Container(
            padding: EdgeInsets.only(top:250),
            child: Text("No sports news available.", style:TextStyle(fontSize: 16)),
          ),
        ],
      ),
    );
  }
}
