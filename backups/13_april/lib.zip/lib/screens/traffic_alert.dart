import 'package:flutter/material.dart';
import '../widgets/widgets.dart';

class TrafficAlertScreen extends StatefulWidget {
  @override
  _TrafficAlertScreen createState() => _TrafficAlertScreen();
}

class _TrafficAlertScreen extends State<TrafficAlertScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        iconTheme: IconThemeData(color: Theme.of(context).cardColor),
        title: Text('Traffic Alert'),
        actions: <Widget>[
          IconButton(
            icon: Icon(
              Icons.add,
              size: 28,
            ),
            onPressed: () {
              print('Add Traffic info.');
            },
          ),
        ],
      ),
      body: Column(
        children: <Widget>[
          Container(
            padding: EdgeInsets.all(15),
            color: Theme.of(context).secondaryHeaderColor,
            child: Column(
              children: <Widget>[
                SizedBox(
                  height: 25,
                  child: TrafficAlertCategoryMenu(),
                )
              ],
            ),
          ),
          Expanded(
            child: ListView(
              physics: AlwaysScrollableScrollPhysics(),
              children: <Widget>[
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 20.0),
                ),
                TrafficAlertContainer(0),
                TrafficAlertContainer(1),
                TrafficAlertContainer(2),
                TrafficAlertContainer(3),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
