import 'package:flutter/material.dart';
import '../models/models.dart';
import '../widgets/widgets.dart';

class StocksScreen extends StatefulWidget {
  @override
  _StocksScreenState createState() => _StocksScreenState();
}

class _StocksScreenState extends State<StocksScreen> {
  double _offsetY = 100;
  ExpandedState _expandedState = ExpandedState.compact;

  double _calculateOffset(delta, context) {
    final maxHeight = MediaQuery.of(context).size.height - 100;
    final newOffset = _offsetY + (delta) * (-1);
    if (newOffset <= 100) {
      return 100;
    } else if (newOffset >= maxHeight) {
      return maxHeight;
    } else {
      return newOffset;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        iconTheme: IconThemeData(color: Theme.of(context).cardColor),
        title: Text('Stocks'),
        actions: <Widget>[
          IconButton(
            icon: Icon(
              Icons.search,
            ),
            onPressed: () {
              print('Search');
            },
          ),
        ],
      ),
      body: Stack(
        children: <Widget>[
          Container(
            padding: EdgeInsets.all(10),
            width: MediaQuery.of(context).size.width,
            //color: Colors.black,
            child: SafeArea(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  SizedBox(
                    height: MediaQuery.of(context).size.height - 190,
                    child: StockList(stocks: Stock.getAll()),
                  ),
                ],
              ),
            ),
          ),
          Positioned(
            bottom: 0,
            child: AnimatedContainer(
              height: _offsetY,
              duration: Duration(milliseconds: 1),
              curve: Curves.easeInOut,
              child: StocksNewsList(
                expandedState: this._expandedState,
                onPanUpdate: (dragDetails) {
                  setState(
                    () {
                      _offsetY =
                          _calculateOffset(dragDetails.primaryDelta, context);
                    },
                  );
                },
                onHeaderTapped: () {
                  debugPrint("onHeaderTapped");
                  setState(
                    () {
                      this._expandedState =
                          this._expandedState == ExpandedState.compact
                              ? ExpandedState.expanded
                              : ExpandedState.compact;
                    },
                  );
                },
              ),
            ),
          ),
        ],
      ),
    );
  }
}
