List<String> sportsCategories = [
  'Cricket',
  'Football',
  'Chess',
  'Volleyball',
  'Wrestling',
  'Table tennis',
  'Basketball',
];