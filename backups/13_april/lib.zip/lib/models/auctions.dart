import 'package:flutter/material.dart';

Color blue = Color(0xff279aff), grey = Color(0xff9f9f9f);

List<String> auctionsCategories = [
  "Building",
  "Land",
  "Car",
  "Animal",
  "Others",
];

List<Map<String, dynamic>> auctionsList = [
  {
    'name': 'Navana Tower',
    'rating': 8.2,
    'imgurl': 'assets/images/auctions/navana-tower-0.jpg',
    'imgs': [
      "assets/images/auctions/navana-tower-1.jpg",
      "assets/images/auctions/navana-tower-2.jpg",
      "assets/images/auctions/navana-tower-3.jpg"
    ],
    'desc':
        'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Inventore saepe mollitia iusto, nesciunt unde libero fugiat minus labore in vero quae, neque ea. Necessitatibus molestias perferendis consequatur voluptatibus, eveniet iusto.'
  },
  {
    'name': 'Orion Group: City Centre Dhaka',
    'rating': 9.1,
    'imgurl': 'assets/images/auctions/ORION_Group_City_Centre_0.jpg',
    'imgs': [
      "assets/images/auctions/ORION_Group_City_Centre_1.jpg",
      "assets/images/auctions/ORION_Group_City_Centre_2.jpg",
      "assets/images/auctions/ORION_Group_City_Centre_0.jpg"
    ],
    'desc':
        'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Inventore saepe mollitia iusto, nesciunt unde libero fugiat minus labore in vero quae, neque ea. Necessitatibus molestias perferendis consequatur voluptatibus, eveniet iusto.'
  },
  {
    'name': 'Bashundhara City Shopping Complex',
    'rating': 8.5,
    'imgurl': 'assets/images/auctions/bashundhara_city_0.jpg',
    'imgs': [
      "assets/images/auctions/bashundhara_city_1.jpg",
      "assets/images/auctions/bashundhara_city_2.jpg",
      "assets/images/auctions/bashundhara_city_3.jpg",
      "assets/images/auctions/bashundhara_city_4.jpg",
    ],
    'desc':
    'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Inventore saepe mollitia iusto, nesciunt unde libero fugiat minus labore in vero quae, neque ea. Necessitatibus molestias perferendis consequatur voluptatibus, eveniet iusto.'
  },
  {
    'name': 'Jabbar Tower',
    'rating': 9.5,
    'imgurl': 'assets/images/auctions/jabbar_tower_0.jpg',
    'imgs': [
      "assets/images/auctions/jabbar_tower_1.jpg",
      "assets/images/auctions/jabbar_tower_2.webp",
      "assets/images/auctions/jabbar_tower_0.jpg",
    ],
    'desc':
    'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Inventore saepe mollitia iusto, nesciunt unde libero fugiat minus labore in vero quae, neque ea. Necessitatibus molestias perferendis consequatur voluptatibus, eveniet iusto.'
  },
  {
    'name': 'Navana Tower',
    'rating': 8.2,
    'imgurl': 'assets/images/auctions/navana-tower-0.jpg',
    'imgs': [
      "assets/images/auctions/navana-tower-1.jpg",
      "assets/images/auctions/navana-tower-2.jpg",
      "assets/images/auctions/navana-tower-3.jpg"
    ],
    'desc':
    'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Inventore saepe mollitia iusto, nesciunt unde libero fugiat minus labore in vero quae, neque ea. Necessitatibus molestias perferendis consequatur voluptatibus, eveniet iusto.'
  },
  {
    'name': 'Orion Group: City Centre',
    'rating': 9.1,
    'imgurl': 'assets/images/auctions/ORION_Group_City_Centre_0.jpg',
    'imgs': [
      "assets/images/auctions/ORION_Group_City_Centre_1.jpg",
      "assets/images/auctions/ORION_Group_City_Centre_2.jpg",
      "assets/images/auctions/ORION_Group_City_Centre_0.jpg"
    ],
    'desc':
    'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Inventore saepe mollitia iusto, nesciunt unde libero fugiat minus labore in vero quae, neque ea. Necessitatibus molestias perferendis consequatur voluptatibus, eveniet iusto.'
  },
  {
    'name': 'Bashundhara City Shopping Complex',
    'rating': 8.5,
    'imgurl': 'assets/images/auctions/bashundhara_city_0.jpg',
    'imgs': [
      "assets/images/auctions/bashundhara_city_1.jpg",
      "assets/images/auctions/bashundhara_city_2.jpg",
      "assets/images/auctions/bashundhara_city_3.jpg",
      "assets/images/auctions/bashundhara_city_4.jpg",
    ],
    'desc':
        'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Inventore saepe mollitia iusto, nesciunt unde libero fugiat minus labore in vero quae, neque ea. Necessitatibus molestias perferendis consequatur voluptatibus, eveniet iusto.'
  },
  {
    'name': 'Jabbar Tower',
    'rating': 9.5,
    'imgurl': 'assets/images/auctions/jabbar_tower_0.jpg',
    'imgs': [
      "assets/images/auctions/jabbar_tower_1.jpg",
      "assets/images/auctions/jabbar_tower_2.webp",
      "assets/images/auctions/jabbar_tower_0.jpg",
    ],
    'desc':
        'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Inventore saepe mollitia iusto, nesciunt unde libero fugiat minus labore in vero quae, neque ea. Necessitatibus molestias perferendis consequatur voluptatibus, eveniet iusto.'
  },
];
