//export 'news_bn.dart';
export 'news_en.dart';
export 'bookmarks.dart';
export 'sports.dart';
export 'stocks.dart';
export 'jobs.dart';
export 'auctions.dart';
export 'sale.dart';
export 'traffic_alert.dart';
export 'puzzles.dart';
export 'wallet.dart';

