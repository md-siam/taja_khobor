import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import '../widgets/widgets.dart';

//custom drawer for android device only
class CustomDrawer extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: ListView(
        children: <Widget>[
          Container(
            width: double.infinity,
            padding: EdgeInsets.all(20),
            color: Theme.of(context).secondaryHeaderColor,
            child: Center(
              child: Column(
                children: <Widget>[
                  Container(
                    width: 100,
                    height: 100,
                    margin: EdgeInsets.only(
                      top: 30,
                      bottom: 10,
                    ),
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      image: new DecorationImage(
                        image: ExactAssetImage('assets/images/main/mdsiam.png'),
                        fit: BoxFit.fitHeight,
                      ),
                    ),
                  ),
                  Text(
                    'Md. Siam',
                    style: TextStyle(fontSize: 22, color: Colors.white),
                  ),
                  Text(
                    'Full-Stack Software Developer',
                    style: TextStyle(color: Colors.white),
                  ),
                ],
              ),
            ),
          ),
          CustomListTile(
            FontAwesomeIcons.home,
            ' Home',
            () => Navigator.of(context).pushNamed('/home'),
          ),
          CustomListTile(
            FontAwesomeIcons.solidBookmark,
            ' Bookmarks',
            () => Navigator.of(context).pushNamed('/bookmarks'),
          ),
          CustomListTile(
            FontAwesomeIcons.satelliteDish,
            ' LIVE Sports',
            () => Navigator.of(context).pushNamed('/LIVE_sports'),
          ),
          CustomListTile(
            FontAwesomeIcons.chartLine,
            ' Stocks',
            () => Navigator.of(context).pushNamed('/stocks'),
          ),
          CustomListTile(
            FontAwesomeIcons.userEdit,
            ' Resume',
            () => Navigator.of(context).pushNamed('/resume'),
          ),
          CustomListTile(
            FontAwesomeIcons.handshake,
            ' Jobs',
            () => Navigator.of(context).pushNamed('/jobs'),
          ),
          CustomListTile(
            FontAwesomeIcons.gavel,
            ' Auctions',
            () => Navigator.of(context).pushNamed('/auctions'),
          ),
          CustomListTile(
            FontAwesomeIcons.tag,
            ' SALE!!',
                () => Navigator.of(context).pushNamed('/sale'),
          ),
          CustomListTile(
            FontAwesomeIcons.trafficLight,
            ' Traffic Alert',
                () => Navigator.of(context).pushNamed('/traffic_alert'),
          ),
          CustomListTile(
            FontAwesomeIcons.cat,
            ' Bheja Bilai',
                () => Navigator.of(context).pushNamed('/bhejabilai'),
          ),
          CustomListTile(
            FontAwesomeIcons.puzzlePiece,
            ' Puzzles',
                () => Navigator.of(context).pushNamed('/puzzles'),
          ),
          const Divider(),
          CustomListTile(
            FontAwesomeIcons.wallet,
            ' Wallet',
            () => Navigator.of(context).pushNamed('/wallet'),
          ),
          CustomListTile(
            FontAwesomeIcons.cog,
            ' Settings',
            () => Navigator.of(context).pushNamed('/settings'),
          ),
          CustomListTile(
            FontAwesomeIcons.weixin,
            ' Help',
            () => Navigator.of(context).pushNamed('/help'),
          ),
          const Divider(),
          SizedBox(
            child: Text(
              '                           Version: 1.0.0',
              style: TextStyle(
                color: Colors.grey,
                fontSize: 14.0,
              ),
            ),
          ),
          const Divider(),
        ],
      ),
    );
  }
}
